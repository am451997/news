import React from 'react';

export default function Settings() {
  return (
    <div className="settings">
      <h1>Admin Settings</h1>
      <p>Manage API Keys, AdSense, AdMob links, etc.</p>
    </div>
  );
}
