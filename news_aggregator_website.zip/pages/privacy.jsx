export default function Privacy() {
  return <h1>Privacy Policy</h1>;
}
