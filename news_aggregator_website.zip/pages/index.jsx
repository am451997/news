export default function Home() {
  return <h1>Welcome to News Aggregator - Homepage (Latest News)</h1>;
}
