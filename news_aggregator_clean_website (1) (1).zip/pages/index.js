
export default function Home() {
  return (
    <div>
      <h1>Welcome to News Aggregator Website</h1>
      <p>This is your Next.js homepage.</p>
    </div>
  );
}
