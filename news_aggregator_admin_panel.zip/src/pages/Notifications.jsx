import React from 'react';

export default function Notifications() {
  return (
    <div className="notifications">
      <h1>Manage Notifications</h1>
      <p>Use Firebase Cloud Messaging to send push notifications.</p>
    </div>
  );
}
