import React from 'react';

export default function DashboardStats() {
  return (
    <div className="stats">
      <h2>Dashboard Overview</h2>
      <p>Users: 100+</p>
      <p>Sessions: 200+</p>
      <p>Revenue: Linked to AdSense & AdMob</p>
    </div>
  );
}
