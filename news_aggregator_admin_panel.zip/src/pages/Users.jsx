import React from 'react';

export default function Users() {
  return (
    <div className="users">
      <h1>Users Analytics (Firebase)</h1>
      <p>View user activity, devices, and regions from Firebase Analytics.</p>
    </div>
  );
}
