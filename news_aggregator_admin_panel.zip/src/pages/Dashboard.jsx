import React from 'react';
import DashboardStats from '../components/DashboardStats';

export default function Dashboard() {
  return (
    <div className="dashboard">
      <h1>Admin Dashboard</h1>
      <DashboardStats />
    </div>
  );
}
