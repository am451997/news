export default function Search() {
  return <h1>Search News</h1>;
}
